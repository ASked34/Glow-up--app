# 🌟 Glow Up Web App

Guía para desplegar tu app de seguimiento de glow up.

## 🚀 Pasos para desplegar en [Vercel](https://vercel.com)

1. Crea una cuenta en Vercel (gratis).
2. Haz clic en "New Project" y selecciona "Import".
3. Sube esta carpeta o conéctala desde un repositorio.
4. Vercel detectará automáticamente que es una app con Vite.
5. Haz clic en "Deploy".

¡Listo! Obtendrás un link como `https://glow-up.vercel.app`.

---
